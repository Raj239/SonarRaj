docker image rm benchmark:latest
docker build -t benchmark .

