#!/bin/sh
mvn compile -Pcrawler
